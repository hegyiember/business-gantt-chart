enum 71891721 "DGOG Gantt Time Grain"
{
    Extensible = true;

    value(0; "Day")
    {
        Caption = 'Day';
    }
    value(1; "Week")
    {
        Caption = 'Week';
    }
    value(2; "Month")
    {
        Caption = 'Month';
    }
    value(3; "Year")
    {
        Caption = 'Year';
    }
}
