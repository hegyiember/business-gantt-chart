enum 71891720 "DGOG Gantt Agg. Bucket Mode"
{
    Extensible = true;

    value(0; "Day")
    {
        Caption = 'Day';
    }
    value(1; "Week")
    {
        Caption = 'Week';
    }
    value(2; "Month")
    {
        Caption = 'Month';
    }
}
