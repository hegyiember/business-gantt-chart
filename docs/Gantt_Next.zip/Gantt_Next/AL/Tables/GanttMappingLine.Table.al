table 71891721 "DGOG Gantt Mapping Line"
{
    Caption = 'Gantt Mapping Line';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Setup ID"; Integer)
        {
            Caption = 'Setup ID';
            TableRelation = "DGOG Gantt Setup"."ID";
        }
        field(2; "View Code"; Code[20])
        {
            Caption = 'View Code';
        }
        field(3; "Line No."; Integer)
        {
            Caption = 'Line No.';
        }
        field(10; "Source Table ID"; Integer)
        {
            Caption = 'Source Table ID';
        }
        field(11; "Parent Line No."; Integer)
        {
            Caption = 'Parent Line No.';
        }
        field(12; "Relation Field ID"; Integer)
        {
            Caption = 'Relation Field ID';
        }
        field(20; "Key Field ID"; Integer)
        {
            Caption = 'Key Field ID';
        }
        field(21; "Description Field ID"; Integer)
        {
            Caption = 'Description Field ID';
        }
        field(30; "Start Date Field ID"; Integer)
        {
            Caption = 'Start Date Field ID';
        }
        field(31; "End Date Field ID"; Integer)
        {
            Caption = 'End Date Field ID';
        }
        field(32; "Due Date Field ID"; Integer)
        {
            Caption = 'Due Date Field ID';
        }
        field(33; "Start Decimal Field ID"; Integer)
        {
            Caption = 'Start Decimal Field ID';
        }
        field(34; "End Decimal Field ID"; Integer)
        {
            Caption = 'End Decimal Field ID';
        }
        field(40; "Status Field ID"; Integer)
        {
            Caption = 'Status Field ID';
        }
        field(41; "Sequence Field ID"; Integer)
        {
            Caption = 'Sequence Field ID';
        }
        field(50; "Is Expandable"; Boolean)
        {
            Caption = 'Is Expandable';
        }
        field(51; "Is Editable"; Boolean)
        {
            Caption = 'Is Editable';
        }
        field(52; "Card Page ID"; Integer)
        {
            Caption = 'Card Page ID';
        }
        field(60; "Grouping Field ID"; Integer)
        {
            Caption = 'Grouping Field ID';
        }
        field(61; "Context Identity Field ID"; Integer)
        {
            Caption = 'Context Identity Field ID';
        }
        field(70; "Resource Group Field ID"; Integer)
        {
            Caption = 'Resource Group Field ID';
        }
        field(80; "Dep. Source Field ID"; Integer)
        {
            Caption = 'Dependency Source Field ID';
        }
        field(81; "Dep. Target Field ID"; Integer)
        {
            Caption = 'Dependency Target Field ID';
        }
        field(82; "Dep. Type Field ID"; Integer)
        {
            Caption = 'Dependency Type Field ID';
        }
        field(90; "Agg. Value Field ID"; Integer)
        {
            Caption = 'Aggregation Value Field ID';
        }
        field(91; "Agg. Capacity Field ID"; Integer)
        {
            Caption = 'Aggregation Capacity Field ID';
        }
        field(92; "Agg. Bucket Mode"; Enum "DGOG Gantt Agg. Bucket Mode")
        {
            Caption = 'Aggregation Bucket Mode';
        }
        field(100; "Conflict Group Field ID"; Integer)
        {
            Caption = 'Conflict Group Field ID';
        }
        field(110; "Progress Override Field ID"; Integer)
        {
            Caption = 'Progress Override Field ID';
        }
        field(111; "Color Override Field ID"; Integer)
        {
            Caption = 'Color Override Field ID';
        }
        field(112; "Label Override Field ID"; Integer)
        {
            Caption = 'Label Override Field ID';
        }
        field(113; "Tooltip Title Field ID"; Integer)
        {
            Caption = 'Tooltip Title Field ID';
        }
    }

    keys
    {
        key(PK; "Setup ID", "View Code", "Line No.")
        {
            Clustered = true;
        }
    }
}
