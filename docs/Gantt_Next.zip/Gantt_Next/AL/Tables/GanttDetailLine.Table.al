table 71891720 "DGOG Gantt Detail Line"
{
    Caption = 'Gantt Detail Line';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Setup ID"; Integer)
        {
            Caption = 'Setup ID';
            TableRelation = "DGOG Gantt Setup"."ID";
        }
        field(2; "View Code"; Code[20])
        {
            Caption = 'View Code';
        }
        field(3; "Mapping Line No."; Integer)
        {
            Caption = 'Mapping Line No.';
        }
        field(4; "Line No."; Integer)
        {
            Caption = 'Line No.';
        }
        field(10; "Field ID"; Integer)
        {
            Caption = 'Field ID';
        }
        field(11; "Caption Override"; Text[80])
        {
            Caption = 'Caption Override';
        }
        field(12; "Sequence"; Integer)
        {
            Caption = 'Sequence';
        }
        field(13; "Is Visible"; Boolean)
        {
            Caption = 'Is Visible';
            InitValue = true;
        }
    }

    keys
    {
        key(PK; "Setup ID", "View Code", "Mapping Line No.", "Line No.")
        {
            Clustered = true;
        }
        key(Seq; "Setup ID", "View Code", "Mapping Line No.", "Sequence") { }
    }
}
