table 71891723 "DGOG Gantt View"
{
    Caption = 'Gantt View';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Setup ID"; Integer)
        {
            Caption = 'Setup ID';
            TableRelation = "DGOG Gantt Setup"."ID";
        }
        field(2; "View Code"; Code[20])
        {
            Caption = 'View Code';
            NotBlank = true;
        }
        field(3; "Name"; Text[100])
        {
            Caption = 'Name';
        }
        field(4; "Description"; Text[250])
        {
            Caption = 'Description';
        }
        field(5; "Sequence"; Integer)
        {
            Caption = 'Sequence';
        }
        field(6; "Is Default"; Boolean)
        {
            Caption = 'Is Default';
        }
        field(7; "Root Mapping Line No."; Integer)
        {
            Caption = 'Root Mapping Line No.';
        }
        field(8; "Aggregation Enabled"; Boolean)
        {
            Caption = 'Aggregation Enabled';
        }
        field(9; "Dependency Enabled"; Boolean)
        {
            Caption = 'Dependency Enabled';
        }
        field(10; "Conflict Detection Enabled"; Boolean)
        {
            Caption = 'Conflict Detection Enabled';
        }
    }

    keys
    {
        key(PK; "Setup ID", "View Code")
        {
            Clustered = true;
        }
        key(Sequence; "Setup ID", "Sequence") { }
    }
}
