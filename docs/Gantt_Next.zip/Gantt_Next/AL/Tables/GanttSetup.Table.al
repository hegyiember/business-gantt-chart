table 71891722 "DGOG Gantt Setup"
{
    Caption = 'Gantt Setup';
    DataClassification = CustomerContent;
    LookupPageId = "DGOG Gantt Setup List";
    DrillDownPageId = "DGOG Gantt Setup List";

    fields
    {
        field(1; "ID"; Integer)
        {
            Caption = 'ID';
            NotBlank = true;
        }
        field(2; "Name"; Text[100])
        {
            Caption = 'Name';
        }
        field(3; "Description"; Text[250])
        {
            Caption = 'Description';
        }
        field(4; "Default View Code"; Code[20])
        {
            Caption = 'Default View Code';
            TableRelation = "DGOG Gantt View"."View Code" where("Setup ID" = field("ID"));
        }
        field(5; "Active"; Boolean)
        {
            Caption = 'Active';
            InitValue = true;
        }
        field(6; "Default Zoom %"; Integer)
        {
            Caption = 'Default Zoom %';
            InitValue = 100;
            MinValue = 30;
            MaxValue = 400;
        }
        field(7; "Default Time Grain"; Enum "DGOG Gantt Time Grain")
        {
            Caption = 'Default Time Grain';
        }
        field(8; "Allow Edit"; Boolean)
        {
            Caption = 'Allow Edit';
        }
        field(9; "Allow Save"; Boolean)
        {
            Caption = 'Allow Save';
        }
        field(10; "Enable Dependencies"; Boolean)
        {
            Caption = 'Enable Dependencies';
        }
        field(11; "Enable Aggregation"; Boolean)
        {
            Caption = 'Enable Aggregation';
        }
        field(12; "Enable Conflict Detection"; Boolean)
        {
            Caption = 'Enable Conflict Detection';
        }
        field(13; "Enable View Switching"; Boolean)
        {
            Caption = 'Enable View Switching';
        }
        field(14; "Highest Parent Card Page ID"; Integer)
        {
            Caption = 'Highest Parent Card Page ID';
        }
    }

    keys
    {
        key(PK; "ID")
        {
            Clustered = true;
        }
    }
}
