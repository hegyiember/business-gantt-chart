codeunit 71891720 "DGOG Gantt Data Builder"
{
    /// <summary>
    /// Builds the normalized JSON payload for the Gantt frontend.
    /// Reads setup, views, mapping lines, and source table data dynamically.
    /// </summary>

    procedure BuildPayload(SetupID: Integer; ViewCode: Code[20]; ContextKey: Text): Text
    var
        GanttSetup: Record "DGOG Gantt Setup";
        GanttView: Record "DGOG Gantt View";
        JsonPayload: JsonObject;
        JsonSetup: JsonObject;
        JsonViews: JsonArray;
        JsonRows: JsonArray;
        JsonBars: JsonArray;
        JsonDependencies: JsonArray;
        JsonAggregates: JsonArray;
        ResultText: Text;
    begin
        if not GanttSetup.Get(SetupID) then
            exit('{"error":"Setup not found"}');

        // Resolve active view
        if ViewCode = '' then
            ViewCode := GanttSetup."Default View Code";

        if ViewCode = '' then begin
            GanttView.SetRange("Setup ID", SetupID);
            GanttView.SetRange("Is Default", true);
            if GanttView.FindFirst() then
                ViewCode := GanttView."View Code"
            else begin
                GanttView.SetRange("Is Default");
                if GanttView.FindFirst() then
                    ViewCode := GanttView."View Code";
            end;
        end;

        // Build setup metadata
        JsonSetup.Add('id', SetupID);
        JsonSetup.Add('name', GanttSetup."Name");
        JsonSetup.Add('defaultZoom', GanttSetup."Default Zoom %");
        JsonSetup.Add('allowEdit', GanttSetup."Allow Edit");
        JsonSetup.Add('allowSave', GanttSetup."Allow Save");
        JsonSetup.Add('enableDependencies', GanttSetup."Enable Dependencies");
        JsonSetup.Add('enableAggregation', GanttSetup."Enable Aggregation");
        JsonSetup.Add('enableConflictDetection', GanttSetup."Enable Conflict Detection");
        JsonSetup.Add('enableViewSwitching', GanttSetup."Enable View Switching");

        // Build available views
        BuildViewsArray(SetupID, JsonViews);

        // Build rows and bars from mapping
        BuildRowsAndBars(SetupID, ViewCode, JsonRows, JsonBars);

        // Build dependencies if enabled
        if GanttSetup."Enable Dependencies" then
            BuildDependencies(SetupID, ViewCode, JsonDependencies);

        // Build aggregation buckets if enabled
        if GanttSetup."Enable Aggregation" then
            BuildAggregates(SetupID, ViewCode, JsonAggregates);

        // Assemble payload
        JsonPayload.Add('setup', JsonSetup);
        JsonPayload.Add('activeViewCode', ViewCode);
        JsonPayload.Add('contextKey', ContextKey);
        JsonPayload.Add('views', JsonViews);
        JsonPayload.Add('rows', JsonRows);
        JsonPayload.Add('bars', JsonBars);
        JsonPayload.Add('dependencies', JsonDependencies);
        JsonPayload.Add('aggregates', JsonAggregates);

        JsonPayload.WriteTo(ResultText);
        exit(ResultText);
    end;

    local procedure BuildViewsArray(SetupID: Integer; var JsonViews: JsonArray)
    var
        GanttView: Record "DGOG Gantt View";
        JsonView: JsonObject;
    begin
        GanttView.SetRange("Setup ID", SetupID);
        GanttView.SetCurrentKey("Setup ID", "Sequence");
        if GanttView.FindSet() then
            repeat
                Clear(JsonView);
                JsonView.Add('viewCode', GanttView."View Code");
                JsonView.Add('name', GanttView."Name");
                JsonView.Add('sequence', GanttView."Sequence");
                JsonView.Add('isDefault', GanttView."Is Default");
                JsonViews.Add(JsonView);
            until GanttView.Next() = 0;
    end;

    local procedure BuildRowsAndBars(SetupID: Integer; ViewCode: Code[20]; var JsonRows: JsonArray; var JsonBars: JsonArray)
    var
        MappingLine: Record "DGOG Gantt Mapping Line";
    begin
        // Read mapping lines for the active view, ordered by line no.
        MappingLine.SetRange("Setup ID", SetupID);
        MappingLine.SetRange("View Code", ViewCode);
        if MappingLine.FindSet() then
            repeat
                BuildRowsForMapping(MappingLine, '', 0, JsonRows, JsonBars);
            until MappingLine.Next() = 0;
    end;

    local procedure BuildRowsForMapping(
        MappingLine: Record "DGOG Gantt Mapping Line";
        ParentRowId: Text;
        Level: Integer;
        var JsonRows: JsonArray;
        var JsonBars: JsonArray)
    var
        RecRef: RecordRef;
        KeyFRef, DescFRef, StartFRef, EndFRef, DueFRef : FieldRef;
        StartDecFRef, EndDecFRef, StatusFRef : FieldRef;
        JsonRow: JsonObject;
        JsonBar: JsonObject;
        JsonTooltipFields: JsonArray;
        RowId: Text;
        BarId: Text;
        ProgressPct: Decimal;
    begin
        // Only process root-level mapping lines (parent = 0) or called recursively
        if (Level = 0) and (MappingLine."Parent Line No." <> 0) then
            exit;

        if MappingLine."Source Table ID" = 0 then
            exit;

        RecRef.Open(MappingLine."Source Table ID");
        if RecRef.FindSet() then
            repeat
                RowId := Format(MappingLine."Source Table ID") + '-' + Format(RecRef.RecordId());
                BarId := 'bar-' + RowId;

                Clear(JsonRow);
                JsonRow.Add('rowId', RowId);
                JsonRow.Add('parentRowId', ParentRowId);
                JsonRow.Add('viewCode', MappingLine."View Code");
                JsonRow.Add('mappingLineNo', MappingLine."Line No.");
                JsonRow.Add('sourceTableId', MappingLine."Source Table ID");
                JsonRow.Add('sourceRecordId', Format(RecRef.RecordId()));
                JsonRow.Add('level', Level);
                JsonRow.Add('hasChildren', MappingLine."Is Expandable");
                JsonRow.Add('isExpanded', false);
                JsonRow.Add('isEditable', MappingLine."Is Editable");

                // Key text
                if MappingLine."Key Field ID" <> 0 then begin
                    KeyFRef := RecRef.Field(MappingLine."Key Field ID");
                    JsonRow.Add('keyText', Format(KeyFRef.Value()));
                end else
                    JsonRow.Add('keyText', Format(RecRef.RecordId()));

                // Description
                if MappingLine."Description Field ID" <> 0 then begin
                    DescFRef := RecRef.Field(MappingLine."Description Field ID");
                    JsonRow.Add('descriptionText', Format(DescFRef.Value()));
                end else
                    JsonRow.Add('descriptionText', '');

                // Status
                if MappingLine."Status Field ID" <> 0 then begin
                    StatusFRef := RecRef.Field(MappingLine."Status Field ID");
                    JsonRow.Add('statusValue', Format(StatusFRef.Value()));
                end else
                    JsonRow.Add('statusValue', '');

                // Tooltip fields
                BuildTooltipFields(MappingLine, RecRef, JsonTooltipFields);
                JsonRow.Add('tooltipFields', JsonTooltipFields);

                JsonRows.Add(JsonRow);

                // Build bar
                Clear(JsonBar);
                JsonBar.Add('barId', BarId);
                JsonBar.Add('rowId', RowId);
                JsonBar.Add('sourceTableId', MappingLine."Source Table ID");
                JsonBar.Add('sourceRecordId', Format(RecRef.RecordId()));
                JsonBar.Add('isEditable', MappingLine."Is Editable");
                JsonBar.Add('isMilestone', false);

                // Dates
                if MappingLine."Start Date Field ID" <> 0 then begin
                    StartFRef := RecRef.Field(MappingLine."Start Date Field ID");
                    JsonBar.Add('startDate', Format(StartFRef.Value(), 0, '<Year4>-<Month,2>-<Day,2>'));
                end;
                if MappingLine."End Date Field ID" <> 0 then begin
                    EndFRef := RecRef.Field(MappingLine."End Date Field ID");
                    JsonBar.Add('endDate', Format(EndFRef.Value(), 0, '<Year4>-<Month,2>-<Day,2>'));
                end;
                if MappingLine."Due Date Field ID" <> 0 then begin
                    DueFRef := RecRef.Field(MappingLine."Due Date Field ID");
                    JsonBar.Add('dueDate', Format(DueFRef.Value(), 0, '<Year4>-<Month,2>-<Day,2>'));
                end;

                // Progress
                ProgressPct := 0;
                if (MappingLine."Start Decimal Field ID" <> 0) and (MappingLine."End Decimal Field ID" <> 0) then begin
                    StartDecFRef := RecRef.Field(MappingLine."Start Decimal Field ID");
                    EndDecFRef := RecRef.Field(MappingLine."End Decimal Field ID");
                    if GetDecimalValue(EndDecFRef) <> 0 then
                        ProgressPct := Round(GetDecimalValue(StartDecFRef) / GetDecimalValue(EndDecFRef) * 100, 1);
                end;
                JsonBar.Add('progressPercent', ProgressPct);

                // Status for color
                if MappingLine."Status Field ID" <> 0 then begin
                    StatusFRef := RecRef.Field(MappingLine."Status Field ID");
                    JsonBar.Add('statusValue', Format(StatusFRef.Value()));
                end else
                    JsonBar.Add('statusValue', '');

                JsonBars.Add(JsonBar);

            until RecRef.Next() = 0;

        RecRef.Close();
    end;

    local procedure BuildTooltipFields(
        MappingLine: Record "DGOG Gantt Mapping Line";
        RecRef: RecordRef;
        var JsonTooltipFields: JsonArray)
    var
        DetailLine: Record "DGOG Gantt Detail Line";
        FRef: FieldRef;
        JsonField: JsonObject;
    begin
        Clear(JsonTooltipFields);
        DetailLine.SetRange("Setup ID", MappingLine."Setup ID");
        DetailLine.SetRange("View Code", MappingLine."View Code");
        DetailLine.SetRange("Mapping Line No.", MappingLine."Line No.");
        DetailLine.SetRange("Is Visible", true);
        DetailLine.SetCurrentKey("Setup ID", "View Code", "Mapping Line No.", "Sequence");
        if DetailLine.FindSet() then
            repeat
                if DetailLine."Field ID" <> 0 then begin
                    Clear(JsonField);
                    FRef := RecRef.Field(DetailLine."Field ID");
                    if DetailLine."Caption Override" <> '' then
                        JsonField.Add('caption', DetailLine."Caption Override")
                    else
                        JsonField.Add('caption', FRef.Caption());
                    JsonField.Add('value', Format(FRef.Value()));
                    JsonTooltipFields.Add(JsonField);
                end;
            until DetailLine.Next() = 0;
    end;

    local procedure GetDecimalValue(FRef: FieldRef): Decimal
    var
        DecVal: Decimal;
    begin
        if Evaluate(DecVal, Format(FRef.Value())) then
            exit(DecVal);
        exit(0);
    end;

    local procedure BuildDependencies(SetupID: Integer; ViewCode: Code[20]; var JsonDeps: JsonArray)
    begin
        // Dependencies are resolved from mapping line Dep. Source/Target fields
        // Implementation extends BuildRowsForMapping to capture dependency keys
        // Placeholder for full dependency resolution
    end;

    local procedure BuildAggregates(SetupID: Integer; ViewCode: Code[20]; var JsonAggs: JsonArray)
    begin
        // Aggregation buckets are built from Agg. Value/Capacity fields
        // grouped by resource and bucketed by day/week/month
        // Placeholder for full aggregation calculation
    end;

    procedure HandleBarClick(SetupID: Integer; SourceTableId: Integer; RecordId: Text)
    var
        GanttSetup: Record "DGOG Gantt Setup";
        MappingLine: Record "DGOG Gantt Mapping Line";
        RecRef: RecordRef;
    begin
        // Find the mapping line for this source table to get Card Page ID
        MappingLine.SetRange("Setup ID", SetupID);
        MappingLine.SetRange("Source Table ID", SourceTableId);
        if MappingLine.FindFirst() then begin
            if MappingLine."Card Page ID" <> 0 then begin
                RecRef.Open(SourceTableId);
                // Navigate to card page
                // Page.Run(MappingLine."Card Page ID", RecRef);
            end;
        end;

        // Fallback: use highest parent card page
        if GanttSetup.Get(SetupID) then
            if GanttSetup."Highest Parent Card Page ID" <> 0 then begin
                // Open the highest parent card page
            end;
    end;
}
