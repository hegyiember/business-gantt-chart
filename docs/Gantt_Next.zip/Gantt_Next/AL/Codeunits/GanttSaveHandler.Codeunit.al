codeunit 71891721 "DGOG Gantt Save Handler"
{
    /// <summary>
    /// Handles saving interactive changes from the Gantt frontend
    /// back into BC source tables.
    /// </summary>

    procedure ProcessSave(SetupID: Integer; ViewCode: Code[20]; ChangesJson: Text): Boolean
    var
        JsonChanges: JsonArray;
        JsonChange: JsonObject;
        JsonToken: JsonToken;
        i: Integer;
        SourceTableId: Integer;
        RecordId: Text;
        FieldId: Integer;
        NewValue: Text;
        Success: Boolean;
    begin
        if not JsonChanges.ReadFrom(ChangesJson) then begin
            Message('Invalid changes data');
            exit(false);
        end;

        Success := true;
        for i := 0 to JsonChanges.Count() - 1 do begin
            JsonChanges.Get(i, JsonToken);
            JsonChange := JsonToken.AsObject();

            SourceTableId := GetJsonInt(JsonChange, 'sourceTableId');
            RecordId := GetJsonText(JsonChange, 'sourceRecordId');
            FieldId := GetJsonInt(JsonChange, 'fieldId');
            NewValue := GetJsonText(JsonChange, 'newValue');

            if not ApplyChange(SourceTableId, RecordId, FieldId, NewValue) then
                Success := false;
        end;

        if Success then
            Message('Changes saved successfully.')
        else
            Message('Some changes could not be saved. Please check the data.');

        exit(Success);
    end;

    local procedure ApplyChange(SourceTableId: Integer; RecordIdTxt: Text; FieldId: Integer; NewValue: Text): Boolean
    var
        RecRef: RecordRef;
        FRef: FieldRef;
        RecordId: RecordId;
    begin
        RecRef.Open(SourceTableId);
        Evaluate(RecordId, RecordIdTxt);
        // Locate the record by its record ID
        if not RecRef.Get(RecordId) then begin
            RecRef.Close();
            exit(false);
        end;

        // Validate field exists and is writable
        FRef := RecRef.Field(FieldId);
        if not Evaluate(FRef, NewValue) then begin
            RecRef.Close();
            exit(false);
        end;

        // Validate and modify
        if not RecRef.Modify(true) then begin
            RecRef.Close();
            exit(false);
        end;

        RecRef.Close();
        exit(true);
    end;

    local procedure GetJsonText(JsonObj: JsonObject; Keyl: Text): Text
    var
        JsonToken: JsonToken;
    begin
        if JsonObj.Get(Keyl, JsonToken) then
            exit(JsonToken.AsValue().AsText());
        exit('');
    end;

    local procedure GetJsonInt(JsonObj: JsonObject; Keyl: Text): Integer
    var
        JsonToken: JsonToken;
    begin
        if JsonObj.Get(Keyl, JsonToken) then
            exit(JsonToken.AsValue().AsInteger());
        exit(0);
    end;
}
