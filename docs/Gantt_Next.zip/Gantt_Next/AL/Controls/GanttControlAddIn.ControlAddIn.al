controladdin "DGOG Gantt Control AddIn"
{
    StartupScript = 'src/Features/Gantt_Next/Scripts/GanttStartup.js';
    Scripts = 'src/Features/Gantt_Next/Scripts/GanttEngine.js',
              'src/Features/Gantt_Next/Scripts/GanttInteraction.js';
    StyleSheets = 'src/Features/Gantt_Next/Resources/GanttChart.css';

    RequestedHeight = 600;
    RequestedWidth = 600;
    MinimumHeight = 1;
    MinimumWidth = 1;
    VerticalStretch = true;
    HorizontalStretch = true;

    // AL → JS procedures
    procedure LoadData(DataJson: Text);
    procedure SwitchView(ViewCode: Text);
    procedure ApplyFilter(FilterJson: Text);

    // JS → AL events
    event OnControlReady();
    event OnBarClicked(SourceTableId: Integer; RecordId: Text);
    event OnSaveRequested(ChangesJson: Text);
    event OnReloadRequested();
    event OnViewSwitchRequested(ViewCode: Text; ContextKey: Text);
    event OnRowExpanded(RowId: Text);
    event OnRowCollapsed(RowId: Text);
}
