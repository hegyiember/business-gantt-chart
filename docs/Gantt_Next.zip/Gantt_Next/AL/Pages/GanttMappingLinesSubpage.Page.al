page 71891723 "DGOG Gantt Mapping Lines Subp"
{
    PageType = ListPart;
    ApplicationArea = All;
    SourceTable = "DGOG Gantt Mapping Line";
    Caption = 'Mapping Lines';

    layout
    {
        area(Content)
        {
            repeater(MappingRepeater)
            {
                field("View Code"; Rec."View Code") { }
                field("Line No."; Rec."Line No.") { }
                field("Source Table ID"; Rec."Source Table ID") { }
                field("Parent Line No."; Rec."Parent Line No.") { }
                field("Relation Field ID"; Rec."Relation Field ID") { }
                field("Key Field ID"; Rec."Key Field ID") { }
                field("Description Field ID"; Rec."Description Field ID") { }
                field("Start Date Field ID"; Rec."Start Date Field ID") { }
                field("End Date Field ID"; Rec."End Date Field ID") { }
                field("Due Date Field ID"; Rec."Due Date Field ID") { }
                field("Status Field ID"; Rec."Status Field ID") { }
                field("Is Expandable"; Rec."Is Expandable") { }
                field("Is Editable"; Rec."Is Editable") { }
            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(DetailLines)
            {
                Caption = 'Detail Lines (Tooltip)';
                Image = AllLines;
                RunObject = page "DGOG Gantt Detail Lines";
                RunPageLink = "Setup ID" = field("Setup ID"),
                              "View Code" = field("View Code"),
                              "Mapping Line No." = field("Line No.");
            }
        }
    }
}
