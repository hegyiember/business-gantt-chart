page 71891721 "DGOG Gantt Detail Lines"
{
    PageType = List;
    ApplicationArea = All;
    SourceTable = "DGOG Gantt Detail Line";
    Caption = 'Gantt Detail Lines (Tooltip Fields)';

    layout
    {
        area(Content)
        {
            repeater(DetailRepeater)
            {
                field("Line No."; Rec."Line No.") { }
                field("Field ID"; Rec."Field ID") { }
                field("Caption Override"; Rec."Caption Override") { }
                field("Sequence"; Rec."Sequence") { }
                field("Is Visible"; Rec."Is Visible") { }
            }
        }
    }
}
