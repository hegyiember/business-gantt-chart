page 71891726 "DGOG Gantt View Subpage"
{
    PageType = ListPart;
    ApplicationArea = All;
    SourceTable = "DGOG Gantt View";
    Caption = 'Gantt Views';

    layout
    {
        area(Content)
        {
            repeater(ViewRepeater)
            {
                field("View Code"; Rec."View Code") { }
                field("Name"; Rec."Name") { }
                field("Sequence"; Rec."Sequence") { }
                field("Is Default"; Rec."Is Default") { }
                field("Root Mapping Line No."; Rec."Root Mapping Line No.") { }
                field("Aggregation Enabled"; Rec."Aggregation Enabled") { }
                field("Dependency Enabled"; Rec."Dependency Enabled") { }
                field("Conflict Detection Enabled"; Rec."Conflict Detection Enabled") { }
            }
        }
    }
}
