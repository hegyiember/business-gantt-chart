page 71891722 "DGOG Gantt Diagram Page"
{
    PageType = Card;
    ApplicationArea = All;
    Caption = 'Gantt Diagram';
    UsageCategory = None;

    layout
    {
        area(Content)
        {
            usercontrol(GanttControl; "DGOG Gantt Control AddIn")
            {
                trigger OnControlReady()
                begin
                    CurrControlReady := true;
                    LoadGanttData();
                end;

                trigger OnBarClicked(SourceTableId: Integer; RecordId: Text)
                begin
                    GanttDataBuilder.HandleBarClick(SetupID, SourceTableId, RecordId);
                end;

                trigger OnSaveRequested(ChangesJson: Text)
                begin
                    GanttSaveHandler.ProcessSave(SetupID, ActiveViewCode, ChangesJson);
                    // Reload after save
                    LoadGanttData();
                end;

                trigger OnReloadRequested()
                begin
                    LoadGanttData();
                end;

                trigger OnViewSwitchRequested(ViewCode: Text; ContextKey: Text)
                begin
                    ActiveViewCode := CopyStr(ViewCode, 1, MaxStrLen(ActiveViewCode));
                    ActiveContextKey := ContextKey;
                    LoadGanttData();
                end;

                trigger OnRowExpanded(RowId: Text)
                begin
                    // Track expanded state if needed for persistence
                end;

                trigger OnRowCollapsed(RowId: Text)
                begin
                    // Track collapsed state if needed for persistence
                end;
            }
        }
    }

    var
        GanttDataBuilder: Codeunit "DGOG Gantt Data Builder";
        GanttSaveHandler: Codeunit "DGOG Gantt Save Handler";
        SetupID: Integer;
        ActiveViewCode: Code[20];
        ActiveContextKey: Text;
        CurrControlReady: Boolean;

    procedure SetSetupID(NewSetupID: Integer)
    begin
        SetupID := NewSetupID;
    end;

    local procedure LoadGanttData()
    var
        DataJson: Text;
    begin
        if not CurrControlReady then
            exit;

        DataJson := GanttDataBuilder.BuildPayload(SetupID, ActiveViewCode, ActiveContextKey);
        CurrPage.GanttControl.LoadData(DataJson);
    end;
}
