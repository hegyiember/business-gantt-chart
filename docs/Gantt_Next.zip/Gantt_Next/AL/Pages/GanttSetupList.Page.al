page 71891725 "DGOG Gantt Setup List"
{
    PageType = List;
    ApplicationArea = All;
    UsageCategory = Lists;
    SourceTable = "DGOG Gantt Setup";
    Caption = 'Gantt Setups';
    CardPageId = "DGOG Gantt Setup Card";
    Editable = false;

    layout
    {
        area(Content)
        {
            repeater(SetupRepeater)
            {
                field("ID"; Rec."ID") { }
                field("Name"; Rec."Name") { }
                field("Description"; Rec."Description") { }
                field("Default View Code"; Rec."Default View Code") { }
                field("Active"; Rec."Active") { }
                field("Default Zoom %"; Rec."Default Zoom %") { }
                field("Default Time Grain"; Rec."Default Time Grain") { }
                field("Allow Edit"; Rec."Allow Edit") { }
            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(OpenGantt)
            {
                Caption = 'Open Gantt Diagram';
                Image = View;
                Promoted = true;
                PromotedCategory = Process;
                PromotedIsBig = true;

                trigger OnAction()
                var
                    GanttPage: Page "DGOG Gantt Diagram Page";
                begin
                    GanttPage.SetSetupID(Rec."ID");
                    GanttPage.Run();
                end;
            }
        }
    }
}
