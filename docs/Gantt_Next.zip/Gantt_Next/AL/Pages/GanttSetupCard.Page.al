page 71891724 "DGOG Gantt Setup Card"
{
    PageType = Card;
    ApplicationArea = All;
    SourceTable = "DGOG Gantt Setup";
    Caption = 'Gantt Setup Card';

    layout
    {
        area(Content)
        {
            group(General)
            {
                Caption = 'General';
                field("ID"; Rec."ID") { }
                field("Name"; Rec."Name") { }
                field("Description"; Rec."Description") { }
                field("Active"; Rec."Active") { }
            }
            group(Defaults)
            {
                Caption = 'Defaults';
                field("Default View Code"; Rec."Default View Code") { }
                field("Default Zoom %"; Rec."Default Zoom %") { }
                field("Default Time Grain"; Rec."Default Time Grain") { }
                field("Highest Parent Card Page ID"; Rec."Highest Parent Card Page ID") { }
            }
            group(Features)
            {
                Caption = 'Features';
                field("Allow Edit"; Rec."Allow Edit") { }
                field("Allow Save"; Rec."Allow Save") { }
                field("Enable Dependencies"; Rec."Enable Dependencies") { }
                field("Enable Aggregation"; Rec."Enable Aggregation") { }
                field("Enable Conflict Detection"; Rec."Enable Conflict Detection") { }
                field("Enable View Switching"; Rec."Enable View Switching") { }
            }
            part(Views; "DGOG Gantt View Subpage")
            {
                Caption = 'Views';
                SubPageLink = "Setup ID" = field("ID");
            }
            part(MappingLines; "DGOG Gantt Mapping Lines Subp")
            {
                Caption = 'Mapping Lines';
                SubPageLink = "Setup ID" = field("ID");
            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(OpenGantt)
            {
                Caption = 'Open Gantt Diagram';
                Image = View;
                Promoted = true;
                PromotedCategory = Process;
                PromotedIsBig = true;

                trigger OnAction()
                var
                    GanttPage: Page "DGOG Gantt Diagram Page";
                begin
                    GanttPage.SetSetupID(Rec."ID");
                    GanttPage.Run();
                end;
            }
        }
    }
}
