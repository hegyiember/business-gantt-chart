/* ============================================================
   GanttInteraction.js — Extended interaction features
   Conflict detection, aggregation overlays, keyboard shortcuts
   ============================================================ */

(function () {
    'use strict';

    var LOG_PREFIX = '[GanttNext]';
    function log(cat, msg, data) {
        if (data !== undefined) console.log(LOG_PREFIX + ' [' + cat + '] ' + msg, data);
        else console.log(LOG_PREFIX + ' [' + cat + '] ' + msg);
    }

    if (!window.GanttEngine) {
        log('Error', 'GanttEngine not found, GanttInteraction cannot initialize');
        return;
    }

    var engine = window.GanttEngine;

    // ─── Conflict Detection ───
    engine.detectConflicts = function () {
        var bars = this.data ? this.data.bars || [] : [];
        var groups = {};
        var conflicts = [];

        // Group bars by conflictGroupKey
        for (var i = 0; i < bars.length; i++) {
            var b = bars[i];
            var gk = b.conflictGroupKey;
            if (!gk) continue;
            if (!groups[gk]) groups[gk] = [];
            groups[gk].push(b);
        }

        // Check overlaps within each group
        for (var gk in groups) {
            var grp = groups[gk];
            for (var i = 0; i < grp.length; i++) {
                for (var j = i + 1; j < grp.length; j++) {
                    var a = grp[i], b = grp[j];
                    var aStart = new Date(a.startDate + 'T00:00:00');
                    var aEnd = new Date(a.endDate + 'T00:00:00');
                    var bStart = new Date(b.startDate + 'T00:00:00');
                    var bEnd = new Date(b.endDate + 'T00:00:00');

                    if (aStart <= bEnd && bStart <= aEnd) {
                        conflicts.push({ barA: a.barId, barB: b.barId, group: gk });
                        a._conflict = true;
                        b._conflict = true;
                    }
                }
            }
        }

        log('Conflict', 'Detected ' + conflicts.length + ' overlaps');
        return conflicts;
    };

    // ─── Keyboard Shortcuts ───
    document.addEventListener('keydown', function (e) {
        // Ctrl+S = Save
        if ((e.ctrlKey || e.metaKey) && e.key === 's') {
            e.preventDefault();
            engine._onSave();
        }
        // Ctrl+R = Reload
        if ((e.ctrlKey || e.metaKey) && e.key === 'r') {
            e.preventDefault();
            engine._onReload();
        }
        // Escape = deselect
        if (e.key === 'Escape') {
            engine.selectedBarId = null;
            engine.selectedRowId = null;
            engine._render();
        }
    });

    // ─── Aggregation Rendering (extends render) ───
    engine.renderAggregation = function (body, aggregates, minD, colW, chartW) {
        if (!aggregates || !aggregates.length) return;

        var DAY_MS = 86400000;

        for (var i = 0; i < aggregates.length; i++) {
            var agg = aggregates[i];
            var bStart = new Date(agg.bucketStart + 'T00:00:00');
            var bEnd = new Date(agg.bucketEnd + 'T00:00:00');
            var sOff = Math.round((bStart.getTime() - minD.getTime()) / DAY_MS);
            var eOff = Math.round((bEnd.getTime() - minD.getTime()) / DAY_MS);

            var x = sOff * colW;
            var w = (eOff - sOff + 1) * colW;

            // Capacity utilization bar overlay at top
            var maxH = 30;
            var pct = Math.min(agg.utilizationPercent || 0, 200);
            var h = Math.max(2, maxH * Math.min(pct / 100, 1));

            var bar = document.createElement('div');
            bar.className = 'gn-agg-bar';
            if (agg.isOverloaded) bar.classList.add('gn-agg-overloaded');
            bar.style.cssText = 'position:absolute;left:' + x + 'px;bottom:0;width:' + w + 'px;height:' + h + 'px;';
            body.appendChild(bar);
        }
    };

    log('Init', 'GanttInteraction loaded');

})();
