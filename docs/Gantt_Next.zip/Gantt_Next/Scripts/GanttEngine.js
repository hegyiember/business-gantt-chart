/* ============================================================
   GanttEngine.js — Generic Metadata-Driven Gantt Rendering Engine
   Part of the Gantt_Next framework for Business Central
   No build step required. Vanilla JS for ControlAddIn.
   ============================================================ */

(function () {
    'use strict';

    // ─── Constants ───
    var DAY_MS = 86400000;
    var ROW_H = 52;
    var CHILD_ROW_H = 44;
    var LABEL_W = 260;
    var HEADER_H = 52;
    var BASE_COL = 60;
    var MIN_COL = 14;
    var MAX_COL = 240;
    var INDENT_PX = 20;

    var STATUS_PALETTE = {
        'Planned':       { bar: '#4a90d9', track: '#a3c4e9' },
        'Firm Planned':  { bar: '#e8922e', track: '#f0c68a' },
        'Released':      { bar: '#3aab5c', track: '#8ed4a4' },
        'Finished':      { bar: '#8a8f99', track: '#c2c5cc' },
        'In Progress':   { bar: '#d4a843', track: '#e8d499' },
        'Open':          { bar: '#5b9bd5', track: '#b4d4f0' },
        'Completed':     { bar: '#70ad47', track: '#b6d9a0' },
        'Cancelled':     { bar: '#c44e52', track: '#e0a0a3' }
    };
    var DEFAULT_COLORS = { bar: '#5b9bd5', track: '#b4d4f0' };

    // ─── Logger ───
    var LOG_ENABLED = true;
    var LOG_PREFIX = '[GanttNext]';

    function log(category, msg, data) {
        if (!LOG_ENABLED) return;
        var s = LOG_PREFIX + ' [' + category + '] ' + msg;
        if (data !== undefined) {
            console.log(s, data);
        } else {
            console.log(s);
        }
    }

    // ─── Helpers ───
    function parseD(s) {
        if (!s) return null;
        var d = new Date(s + 'T00:00:00');
        return isNaN(d.getTime()) ? null : d;
    }
    function addDays(d, n) { return new Date(d.getTime() + n * DAY_MS); }
    function diffDays(a, b) { return Math.round((b.getTime() - a.getTime()) / DAY_MS); }
    function isWeekend(d) { var day = d.getDay(); return day === 0 || day === 6; }
    function fmtShort(d) {
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return String(d.getDate()).padStart(2, '0') + ' ' + months[d.getMonth()];
    }
    function fmtMonth(d) {
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return months[d.getMonth()] + ' ' + d.getFullYear();
    }

    function el(tag, cls, parent) {
        var e = document.createElement(tag);
        if (cls) e.className = cls;
        if (parent) parent.appendChild(e);
        return e;
    }

    function css(e, styles) {
        for (var k in styles) e.style[k] = styles[k];
    }

    function getColors(status) {
        if (!status) return DEFAULT_COLORS;
        return STATUS_PALETTE[status] || DEFAULT_COLORS;
    }

    function escHtml(s) {
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    // ─── GanttEngine Constructor ───
    function GanttEngine() {
        log('Init', 'GanttEngine constructor called');

        this.data = null;           // Full payload from AL
        this.visibleRows = [];      // Flattened visible rows after expand/collapse
        this.rowMap = {};           // rowId → row object
        this.barMap = {};           // barId → bar object
        this.barsByRow = {};        // rowId → [bar, ...]

        this.zoom = 1;
        this._tooltip = null;
        this._initialized = false;
        this._pendingLoad = false;

        this.pendingChanges = [];   // Unsaved edits
        this.selectedBarId = null;
        this.selectedRowId = null;

        // Deferred init
        var self = this;
        if (document.body) {
            self._init();
        } else {
            document.addEventListener('DOMContentLoaded', function () {
                log('Init', 'DOMContentLoaded fired');
                self._init();
            });
        }
    }

    // ─── Initialization ───
    GanttEngine.prototype._init = function () {
        log('Init', '_init started, readyState=' + document.readyState);

        var root = document.getElementById('controlAddIn')
            || document.getElementById('controlAddin')
            || document.getElementById('ControlAddIn');
        log('Init', 'Root by ID: ' + (root ? root.id : 'none'));

        if (!root) {
            var scripts = document.getElementsByTagName('script');
            for (var i = scripts.length - 1; i >= 0; i--) {
                if (scripts[i].src && scripts[i].src.indexOf('GanttEngine') !== -1) {
                    var sp = scripts[i].parentElement;
                    if (sp && sp.tagName !== 'HEAD') {
                        root = sp;
                        log('Init', 'Root via script parent: ' + root.tagName);
                    }
                    break;
                }
            }
        }
        if (!root) {
            log('Init', 'No root found, using document.body');
            root = document.body;
        }

        root.innerHTML = '';
        var wrap = el('div', 'gn-wrap', root);
        wrap.id = 'gantt-next-container';
        this._wrap = wrap;
        this._root = root;

        // ── Toolbar ──
        var toolbar = el('div', 'gn-toolbar', wrap);

        var titleArea = el('div', 'gn-title-area', toolbar);
        this._titleEl = el('h2', 'gn-title', titleArea);
        this._titleEl.textContent = 'Gantt Diagram';

        // View switcher
        this._viewSwitcher = el('div', 'gn-view-switcher', titleArea);
        this._viewSwitcher.style.display = 'none';

        var controls = el('div', 'gn-controls', toolbar);

        // Legend
        this._legendEl = el('div', 'gn-legend', controls);

        // Dirty indicator
        this._dirtyDot = el('span', 'gn-dirty-dot', controls);
        this._dirtyDot.title = 'Unsaved changes';
        this._dirtyDot.style.display = 'none';

        // Save / Reload buttons
        var actionBtns = el('div', 'gn-action-btns', controls);
        this._saveBtn = el('button', 'gn-action-btn gn-save-btn', actionBtns);
        this._saveBtn.textContent = '\uD83D\uDCBE Save';
        this._saveBtn.style.display = 'none';
        this._reloadBtn = el('button', 'gn-action-btn gn-reload-btn', actionBtns);
        this._reloadBtn.textContent = '\u21BB Reload';

        var self = this;
        this._saveBtn.onclick = function () { self._onSave(); };
        this._reloadBtn.onclick = function () { self._onReload(); };

        // Zoom
        var zoomWrap = el('div', 'gn-zoom', controls);
        var btnMinus = el('button', 'gn-zoom-btn', zoomWrap);
        btnMinus.textContent = '\u2212';
        this._zoomLabel = el('span', 'gn-zoom-label', zoomWrap);
        this._zoomLabel.textContent = '100%';
        var btnPlus = el('button', 'gn-zoom-btn', zoomWrap);
        btnPlus.textContent = '+';

        btnMinus.onclick = function () { self._setZoom(self.zoom - 0.1); };
        btnPlus.onclick = function () { self._setZoom(self.zoom + 0.1); };

        // ── Chart area ──
        var chartArea = el('div', 'gn-chart-area', wrap);
        this._chartArea = chartArea;

        this._labelCol = el('div', 'gn-label-col', chartArea);
        css(this._labelCol, { width: LABEL_W + 'px' });

        this._scrollArea = el('div', 'gn-scroll-area', chartArea);

        // Sync vertical scroll
        this._scrollArea.addEventListener('scroll', function () {
            self._labelCol.scrollTop = self._scrollArea.scrollTop;
        });

        // Ctrl+scroll zoom
        chartArea.addEventListener('wheel', function (e) {
            if (e.ctrlKey || e.metaKey) {
                e.preventDefault();
                self._setZoom(self.zoom + (e.deltaY > 0 ? -0.1 : 0.1));
            }
        }, { passive: false });

        this._initialized = true;
        log('Init', '_init complete');

        if (this._pendingLoad && this.data) {
            log('Init', 'Rendering deferred data');
            this._pendingLoad = false;
            this._processData();
        }
    };

    // ─── Data Loading ───
    GanttEngine.prototype.load = function (jsonStr) {
        log('Data', 'load() called, length=' + (jsonStr ? jsonStr.length : 0));
        try {
            this.data = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        } catch (e) {
            log('Error', 'JSON parse error', e);
            return;
        }

        if (!this._initialized) {
            log('Data', 'Not initialized, deferring');
            this._pendingLoad = true;
            return;
        }
        this._processData();
    };

    GanttEngine.prototype._processData = function () {
        var data = this.data;
        if (!data) return;
        log('Data', 'Processing payload');

        // Setup
        var setup = data.setup || {};
        this.zoom = (setup.defaultZoom || 100) / 100;
        this._zoomLabel.textContent = Math.round(this.zoom * 100) + '%';
        this._titleEl.textContent = setup.name || 'Gantt Diagram';

        // Index rows and bars
        this.rowMap = {};
        this.barMap = {};
        this.barsByRow = {};
        this.pendingChanges = [];
        this._updateDirtyState();

        var rows = data.rows || [];
        var bars = data.bars || [];

        for (var i = 0; i < rows.length; i++) {
            var r = rows[i];
            r.children = [];
            r.isExpanded = r.isExpanded || false;
            this.rowMap[r.rowId] = r;
        }

        // Build parent-child relationships
        for (var i = 0; i < rows.length; i++) {
            var r = rows[i];
            if (r.parentRowId && this.rowMap[r.parentRowId]) {
                this.rowMap[r.parentRowId].children.push(r);
                this.rowMap[r.parentRowId].hasChildren = true;
            }
        }

        // Index bars
        for (var i = 0; i < bars.length; i++) {
            var b = bars[i];
            this.barMap[b.barId] = b;
            if (!this.barsByRow[b.rowId]) this.barsByRow[b.rowId] = [];
            this.barsByRow[b.rowId].push(b);
        }

        log('Data', 'Indexed ' + rows.length + ' rows, ' + bars.length + ' bars');

        // Build views
        this._buildViewSwitcher(data.views || []);

        // Build legend from visible statuses
        this._buildLegend(bars);

        // Show save/reload if allowed
        if (setup.allowSave) {
            this._saveBtn.style.display = '';
        }

        this._flattenVisibleRows();
        this._render();
    };

    // ─── Flatten visible rows (respecting expand/collapse) ───
    GanttEngine.prototype._flattenVisibleRows = function () {
        var data = this.data;
        var rows = data.rows || [];
        var result = [];

        // Find root rows (no parent or parent not in current set)
        var rootRows = [];
        for (var i = 0; i < rows.length; i++) {
            if (!rows[i].parentRowId || !this.rowMap[rows[i].parentRowId]) {
                rootRows.push(rows[i]);
            }
        }

        function addRow(row) {
            result.push(row);
            if (row.isExpanded && row.children) {
                for (var j = 0; j < row.children.length; j++) {
                    addRow(row.children[j]);
                }
            }
        }

        for (var i = 0; i < rootRows.length; i++) {
            addRow(rootRows[i]);
        }

        this.visibleRows = result;
        log('View', 'Flattened to ' + result.length + ' visible rows');
    };

    // ─── View Switcher ───
    GanttEngine.prototype._buildViewSwitcher = function (views) {
        this._viewSwitcher.innerHTML = '';
        if (!views || views.length <= 1) {
            this._viewSwitcher.style.display = 'none';
            return;
        }

        var self = this;
        var activeCode = this.data.activeViewCode;
        this._viewSwitcher.style.display = 'flex';

        for (var i = 0; i < views.length; i++) {
            (function (v) {
                var btn = el('button', 'gn-view-btn', self._viewSwitcher);
                btn.textContent = v.name || v.viewCode;
                if (v.viewCode === activeCode) btn.classList.add('gn-view-active');
                btn.onclick = function () {
                    log('View', 'Switching to view: ' + v.viewCode);
                    if (typeof Microsoft !== 'undefined') {
                        var ctxKey = self.selectedRowId ? (self.rowMap[self.selectedRowId] || {}).contextKey || '' : '';
                        Microsoft.Dynamics.NAV.InvokeExtensibilityMethod('OnViewSwitchRequested', [v.viewCode, ctxKey]);
                    }
                };
            })(views[i]);
        }
    };

    // ─── Legend ───
    GanttEngine.prototype._buildLegend = function (bars) {
        this._legendEl.innerHTML = '';
        var seen = {};
        for (var i = 0; i < bars.length; i++) {
            var s = bars[i].statusValue;
            if (s && !seen[s]) {
                seen[s] = true;
                var item = el('span', 'gn-legend-item', this._legendEl);
                var dot = el('span', 'gn-legend-dot', item);
                dot.style.background = getColors(s).bar;
                item.appendChild(document.createTextNode(s));
            }
        }
    };

    // ─── Zoom ───
    GanttEngine.prototype._setZoom = function (z) {
        z = Math.round(z * 10) / 10;
        this.zoom = Math.max(0.3, Math.min(4, z));
        this._zoomLabel.textContent = Math.round(this.zoom * 100) + '%';
        log('View', 'Zoom set to ' + Math.round(this.zoom * 100) + '%');
        this._render();
    };

    // ─── Tooltip ───
    GanttEngine.prototype._ensureTooltip = function () {
        if (!this._tooltip) {
            this._tooltip = el('div', 'gn-tooltip');
            (document.body || this._wrap.parentElement).appendChild(this._tooltip);
        }
    };

    GanttEngine.prototype._showTooltip = function (html, x, y) {
        this._ensureTooltip();
        this._tooltip.innerHTML = html;
        this._tooltip.style.display = 'block';
        this._tooltip.style.left = x + 'px';
        this._tooltip.style.top = y + 'px';
        this._tooltip.style.transform = 'translate(-50%, -100%)';
    };

    GanttEngine.prototype._hideTooltip = function () {
        if (this._tooltip) this._tooltip.style.display = 'none';
    };

    // ─── Expand / Collapse ───
    GanttEngine.prototype._toggleRow = function (rowId) {
        var row = this.rowMap[rowId];
        if (!row || !row.hasChildren) return;

        row.isExpanded = !row.isExpanded;
        log('Interaction', (row.isExpanded ? 'Expanded' : 'Collapsed') + ' row: ' + rowId);

        if (typeof Microsoft !== 'undefined') {
            var evt = row.isExpanded ? 'OnRowExpanded' : 'OnRowCollapsed';
            Microsoft.Dynamics.NAV.InvokeExtensibilityMethod(evt, [rowId]);
        }

        this._flattenVisibleRows();
        this._render();
    };

    // ─── Save / Reload ───
    GanttEngine.prototype._onSave = function () {
        if (this.pendingChanges.length === 0) return;
        log('Edit', 'Save requested, ' + this.pendingChanges.length + ' changes');
        if (typeof Microsoft !== 'undefined') {
            Microsoft.Dynamics.NAV.InvokeExtensibilityMethod('OnSaveRequested', [JSON.stringify(this.pendingChanges)]);
        }
    };

    GanttEngine.prototype._onReload = function () {
        log('Edit', 'Reload requested');
        if (typeof Microsoft !== 'undefined') {
            Microsoft.Dynamics.NAV.InvokeExtensibilityMethod('OnReloadRequested', []);
        }
    };

    GanttEngine.prototype._updateDirtyState = function () {
        var dirty = this.pendingChanges.length > 0;
        if (this._dirtyDot) this._dirtyDot.style.display = dirty ? '' : 'none';
        if (this._saveBtn) {
            this._saveBtn.classList.toggle('gn-save-active', dirty);
        }
    };

    // ─── Main Render ───
    GanttEngine.prototype._render = function () {
        var rows = this.visibleRows;
        if (!rows || !rows.length) {
            log('Render', 'No visible rows');
            this._labelCol.innerHTML = '<div class="gn-empty">No records to display</div>';
            this._scrollArea.innerHTML = '';
            return;
        }

        log('Render', 'Rendering ' + rows.length + ' rows at zoom ' + Math.round(this.zoom * 100) + '%');

        var self = this;
        var colW = Math.max(MIN_COL, Math.min(MAX_COL, BASE_COL * this.zoom));

        // ── Compute date range across all bars ──
        var allBars = this.data.bars || [];
        if (!allBars.length) return;

        var minD = null, maxD = null;
        for (var i = 0; i < allBars.length; i++) {
            var s = parseD(allBars[i].startDate);
            var e = parseD(allBars[i].endDate);
            var dd = parseD(allBars[i].dueDate);
            if (s && (!minD || s < minD)) minD = s;
            if (e && (!maxD || e > maxD)) maxD = e;
            if (dd && (!maxD || dd > maxD)) maxD = dd;
            if (dd && (!minD || dd < minD)) minD = dd;
        }

        if (!minD || !maxD) return;
        minD = addDays(minD, -3);
        maxD = addDays(maxD, 3);

        var totalDays = diffDays(minD, maxD) + 1;
        var days = [];
        for (var d = 0; d < totalDays; d++) days.push(addDays(minD, d));

        var chartW = totalDays * colW;

        // Row heights
        var rowHeights = [];
        var totalH = 0;
        for (var i = 0; i < rows.length; i++) {
            var h = rows[i].level > 0 ? CHILD_ROW_H : ROW_H;
            rowHeights.push(h);
            totalH += h;
        }

        var today = new Date(); today.setHours(0, 0, 0, 0);
        var todayOff = diffDays(minD, today);

        // ── Labels ──
        this._labelCol.innerHTML = '';
        var labelSpacer = el('div', 'gn-label-spacer', this._labelCol);
        css(labelSpacer, { height: HEADER_H + 'px' });

        for (var i = 0; i < rows.length; i++) {
            (function (row, idx) {
                var rowH = rowHeights[idx];
                var rowEl = el('div', 'gn-label-row', self._labelCol);
                css(rowEl, { height: rowH + 'px' });
                if (row.rowId === self.selectedRowId) rowEl.classList.add('gn-label-selected');

                // Indent
                var indent = row.level * INDENT_PX;
                css(rowEl, { paddingLeft: (12 + indent) + 'px' });

                // Expand/collapse button
                if (row.hasChildren) {
                    var expBtn = el('span', 'gn-expand-btn', rowEl);
                    expBtn.textContent = row.isExpanded ? '\u25BC' : '\u25B6';
                    expBtn.onclick = function (e) {
                        e.stopPropagation();
                        self._toggleRow(row.rowId);
                    };
                } else {
                    var spacer = el('span', 'gn-expand-spacer', rowEl);
                }

                // Status dot
                var colors = getColors(row.statusValue);
                var dot = el('span', 'gn-label-dot', rowEl);
                dot.style.background = colors.bar;

                // Key text
                var txt = el('span', 'gn-label-text', rowEl);
                txt.textContent = row.keyText || '';

                // Description
                var desc = el('div', 'gn-label-desc', rowEl);
                desc.textContent = row.descriptionText || '';
                desc.style.paddingLeft = (indent + 30) + 'px';

                // Row click for selection
                rowEl.onclick = function () {
                    self.selectedRowId = row.rowId;
                    self._render();
                };

                // Tooltip on hover
                if (row.tooltipFields && row.tooltipFields.length > 0) {
                    rowEl.addEventListener('mouseenter', function (ev) {
                        var r = rowEl.getBoundingClientRect();
                        var html = '<b>' + escHtml(row.keyText) + '</b><br>';
                        if (row.descriptionText) html += '<span class="gn-tt-dim">' + escHtml(row.descriptionText) + '</span><br>';
                        for (var t = 0; t < row.tooltipFields.length; t++) {
                            var tf = row.tooltipFields[t];
                            html += '<span class="gn-tt-dim">' + escHtml(tf.caption) + ':</span> ' + escHtml(tf.value) + '<br>';
                        }
                        self._showTooltip(html, r.right + 8, r.top);
                    });
                    rowEl.addEventListener('mouseleave', function () { self._hideTooltip(); });
                }
            })(rows[i], i);
        }

        // ── Grid ──
        this._scrollArea.innerHTML = '';
        var canvas = el('div', 'gn-canvas', this._scrollArea);
        css(canvas, { width: chartW + 'px', minHeight: (totalH + HEADER_H) + 'px' });

        // Month header
        var monthRow = el('div', 'gn-month-row', canvas);
        css(monthRow, { height: '26px' });
        var curMonth = '', mStart = 0;
        for (var d = 0; d <= days.length; d++) {
            var ml = d < days.length ? fmtMonth(days[d]) : '';
            if (ml !== curMonth) {
                if (curMonth) {
                    var mCell = el('div', 'gn-month-cell', monthRow);
                    css(mCell, { width: (d - mStart) * colW + 'px' });
                    mCell.textContent = curMonth;
                }
                curMonth = ml; mStart = d;
            }
        }

        // Day header
        var dayRow = el('div', 'gn-day-row', canvas);
        css(dayRow, { height: '26px' });
        for (var d = 0; d < days.length; d++) {
            var dc = el('div', 'gn-day-cell', dayRow);
            css(dc, { width: colW + 'px', minWidth: colW + 'px', maxWidth: colW + 'px' });
            if (isWeekend(days[d])) dc.classList.add('gn-weekend-cell');
            if (colW > 38) dc.textContent = fmtShort(days[d]);
            else if (colW > 24) dc.textContent = String(days[d].getDate());
        }

        // Grid body
        var body = el('div', 'gn-body', canvas);
        css(body, { height: totalH + 'px', position: 'relative' });

        // Weekend columns
        for (var d = 0; d < days.length; d++) {
            if (isWeekend(days[d])) {
                var wc = el('div', 'gn-weekend-col', body);
                css(wc, { left: d * colW + 'px', width: colW + 'px', height: totalH + 'px' });
            }
        }

        // Vertical grid lines
        for (var d = 0; d <= days.length; d++) {
            var vl = el('div', 'gn-vline', body);
            css(vl, { left: d * colW + 'px', height: totalH + 'px' });
        }

        // Horizontal grid lines
        var yOff = 0;
        for (var i = 0; i <= rows.length; i++) {
            var hl = el('div', 'gn-hline', body);
            css(hl, { top: yOff + 'px', width: chartW + 'px' });
            if (i < rows.length) yOff += rowHeights[i];
        }

        // Today line
        if (todayOff >= 0 && todayOff < totalDays) {
            var tl = el('div', 'gn-today-line', body);
            css(tl, { left: (todayOff * colW + colW / 2) + 'px', height: totalH + 'px' });
            var tLabel = el('div', 'gn-today-label', tl);
            tLabel.textContent = 'Today';
        }

        // ── Bars ──
        yOff = 0;
        for (var i = 0; i < rows.length; i++) {
            var row = rows[i];
            var rowH = rowHeights[i];
            var rowBars = this.barsByRow[row.rowId] || [];

            for (var b = 0; b < rowBars.length; b++) {
                (function (bar, rowY, rh, rowLevel) {
                    var sd = parseD(bar.startDate);
                    var ed = parseD(bar.endDate);
                    if (!sd || !ed) return;

                    var sOff = diffDays(minD, sd);
                    var eOff = diffDays(minD, ed);
                    var bLeft = sOff * colW + 2;
                    var bW = Math.max((eOff - sOff + 1) * colW - 4, 8);
                    var barH = rowLevel > 0 ? rh - 22 : rh - 20;
                    var barTop = rowLevel > 0 ? rowY + 11 : rowY + 10;
                    var colors = getColors(bar.statusValue);

                    var barEl = el('div', 'gn-bar', body);
                    if (rowLevel > 0) barEl.classList.add('gn-bar-child');
                    css(barEl, {
                        left: bLeft + 'px',
                        top: barTop + 'px',
                        width: bW + 'px',
                        height: barH + 'px',
                        background: colors.track
                    });

                    // Selected state
                    if (bar.barId === self.selectedBarId) barEl.classList.add('gn-bar-selected');

                    // Progress fill
                    var progress = Math.min(1, Math.max(0, (bar.progressPercent || 0) / 100));
                    var fill = el('div', 'gn-bar-fill', barEl);
                    css(fill, { width: (progress * 100) + '%', background: colors.bar });

                    // Label
                    if (bW > 50) {
                        var lbl = el('span', 'gn-bar-label', barEl);
                        lbl.textContent = Math.round(progress * 100) + '%';
                    }

                    // Due date marker (diamond)
                    var dueD = parseD(bar.dueDate);
                    if (dueD) {
                        var dueOff = diffDays(minD, dueD);
                        var dueX = dueOff * colW + colW / 2;
                        var dueMark = el('div', 'gn-due-marker', body);
                        css(dueMark, {
                            left: (dueX - 5) + 'px',
                            top: (barTop + barH / 2 - 5) + 'px'
                        });
                    }

                    // Click
                    barEl.style.cursor = 'pointer';
                    barEl.addEventListener('click', function (e) {
                        e.stopPropagation();
                        self.selectedBarId = bar.barId;
                        self.selectedRowId = bar.rowId;
                        log('Interaction', 'Bar clicked: ' + bar.barId);
                        if (typeof Microsoft !== 'undefined') {
                            Microsoft.Dynamics.NAV.InvokeExtensibilityMethod('OnBarClicked', [bar.sourceTableId, bar.sourceRecordId]);
                        }
                        self._render();
                    });

                    // Tooltip
                    barEl.addEventListener('mouseenter', function (ev) {
                        var r = barEl.getBoundingClientRect();
                        var rowData = self.rowMap[bar.rowId] || {};
                        var html = '<b>' + escHtml(rowData.keyText || '') + '</b><br>';
                        if (rowData.descriptionText) html += '<span class="gn-tt-dim">' + escHtml(rowData.descriptionText) + '</span><br>';
                        html += '<span class="gn-tt-dim">Start:</span> ' + (bar.startDate || '') + '<br>';
                        html += '<span class="gn-tt-dim">End:</span> ' + (bar.endDate || '') + '<br>';
                        if (bar.dueDate) html += '<span class="gn-tt-dim">Due:</span> ' + bar.dueDate + '<br>';
                        html += '<span class="gn-tt-dim">Progress:</span> ' + Math.round(progress * 100) + '%<br>';
                        if (bar.statusValue) html += '<span class="gn-tt-dim">Status:</span> ' + escHtml(bar.statusValue) + '<br>';

                        // Add tooltip detail fields from row
                        if (rowData.tooltipFields) {
                            for (var t = 0; t < rowData.tooltipFields.length; t++) {
                                var tf = rowData.tooltipFields[t];
                                html += '<span class="gn-tt-dim">' + escHtml(tf.caption) + ':</span> ' + escHtml(tf.value) + '<br>';
                            }
                        }

                        self._showTooltip(html, r.left + r.width / 2, r.top - 6);
                    });
                    barEl.addEventListener('mouseleave', function () { self._hideTooltip(); });

                    // Make draggable if editable
                    if (bar.isEditable && self.data.setup && self.data.setup.allowEdit) {
                        self._makeBarDraggable(barEl, bar, minD, colW);
                    }

                })(rowBars[b], yOff, rowH, row.level);
            }

            yOff += rowH;
        }

        // ── Dependency arrows (SVG overlay) ──
        var deps = this.data.dependencies || [];
        if (deps.length > 0 && this.data.setup && this.data.setup.enableDependencies) {
            this._renderDependencies(body, deps, minD, colW, rowHeights, rows);
        }

        log('Render', 'Render complete');
    };

    // ─── Dependency Rendering ───
    GanttEngine.prototype._renderDependencies = function (body, deps, minD, colW, rowHeights, rows) {
        var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('class', 'gn-dep-svg');
        var totalH = 0;
        for (var i = 0; i < rowHeights.length; i++) totalH += rowHeights[i];
        svg.setAttribute('width', body.style.width);
        svg.setAttribute('height', totalH + 'px');
        css(svg, { position: 'absolute', top: '0', left: '0', pointerEvents: 'none', zIndex: '5' });

        // Build row Y position index
        var rowYMap = {};
        var yOff = 0;
        for (var i = 0; i < rows.length; i++) {
            rowYMap[rows[i].rowId] = yOff + rowHeights[i] / 2;
            yOff += rowHeights[i];
        }

        for (var d = 0; d < deps.length; d++) {
            var dep = deps[d];
            var srcBar = this.barMap[dep.sourceBarId];
            var tgtBar = this.barMap[dep.targetBarId];
            if (!srcBar || !tgtBar) continue;

            var srcEnd = parseD(srcBar.endDate);
            var tgtStart = parseD(tgtBar.startDate);
            if (!srcEnd || !tgtStart) continue;

            var x1 = (diffDays(minD, srcEnd) + 1) * colW;
            var y1 = rowYMap[srcBar.rowId] || 0;
            var x2 = diffDays(minD, tgtStart) * colW;
            var y2 = rowYMap[tgtBar.rowId] || 0;

            var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            var midX = (x1 + x2) / 2;
            path.setAttribute('d', 'M ' + x1 + ' ' + y1 + ' C ' + midX + ' ' + y1 + ' ' + midX + ' ' + y2 + ' ' + x2 + ' ' + y2);
            path.setAttribute('stroke', '#5b7a99');
            path.setAttribute('stroke-width', '1.5');
            path.setAttribute('fill', 'none');
            path.setAttribute('marker-end', 'url(#gn-arrow)');

            // Highlight if selected
            if (this.selectedBarId === dep.sourceBarId || this.selectedBarId === dep.targetBarId) {
                path.setAttribute('stroke', '#2E75B6');
                path.setAttribute('stroke-width', '2.5');
            }

            svg.appendChild(path);
        }

        // Arrow marker definition
        var defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
        var marker = document.createElementNS('http://www.w3.org/2000/svg', 'marker');
        marker.setAttribute('id', 'gn-arrow');
        marker.setAttribute('markerWidth', '8');
        marker.setAttribute('markerHeight', '6');
        marker.setAttribute('refX', '8');
        marker.setAttribute('refY', '3');
        marker.setAttribute('orient', 'auto');
        var polygon = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
        polygon.setAttribute('points', '0 0, 8 3, 0 6');
        polygon.setAttribute('fill', '#5b7a99');
        marker.appendChild(polygon);
        defs.appendChild(marker);
        svg.insertBefore(defs, svg.firstChild);

        body.appendChild(svg);
    };

    // ─── Draggable Bars ───
    GanttEngine.prototype._makeBarDraggable = function (barEl, bar, minD, colW) {
        var self = this;
        var startX, origLeft, origWidth, dragMode; // 'move', 'resize-left', 'resize-right'

        // Resize handles
        var handleL = el('div', 'gn-resize-handle gn-resize-left', barEl);
        var handleR = el('div', 'gn-resize-handle gn-resize-right', barEl);

        function onDown(e, mode) {
            e.preventDefault();
            e.stopPropagation();
            startX = e.clientX;
            origLeft = parseInt(barEl.style.left, 10);
            origWidth = parseInt(barEl.style.width, 10);
            dragMode = mode;
            log('Interaction', 'Drag start: ' + mode + ' on ' + bar.barId);

            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        }

        function onMove(e) {
            var dx = e.clientX - startX;
            if (dragMode === 'move') {
                barEl.style.left = (origLeft + dx) + 'px';
            } else if (dragMode === 'resize-right') {
                barEl.style.width = Math.max(8, origWidth + dx) + 'px';
            } else if (dragMode === 'resize-left') {
                barEl.style.left = (origLeft + dx) + 'px';
                barEl.style.width = Math.max(8, origWidth - dx) + 'px';
            }
        }

        function onUp(e) {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);

            var newLeft = parseInt(barEl.style.left, 10);
            var newWidth = parseInt(barEl.style.width, 10);

            // Calculate new dates
            var newStartDayOff = Math.round((newLeft - 2) / colW);
            var newEndDayOff = Math.round((newLeft + newWidth + 2) / colW) - 1;
            var newStart = addDays(minD, newStartDayOff);
            var newEnd = addDays(minD, newEndDayOff);

            var fmtDate = function (d) {
                return d.getFullYear() + '-' +
                    String(d.getMonth() + 1).padStart(2, '0') + '-' +
                    String(d.getDate()).padStart(2, '0');
            };

            var oldStart = bar.startDate;
            var oldEnd = bar.endDate;
            var newStartStr = fmtDate(newStart);
            var newEndStr = fmtDate(newEnd);

            if (newStartStr !== oldStart || newEndStr !== oldEnd) {
                log('Edit', 'Bar ' + bar.barId + ' moved: ' + oldStart + '→' + newStartStr + ', ' + oldEnd + '→' + newEndStr);

                // Update bar data
                bar.startDate = newStartStr;
                bar.endDate = newEndStr;

                // Record pending changes
                if (newStartStr !== oldStart) {
                    self.pendingChanges.push({
                        sourceTableId: bar.sourceTableId,
                        sourceRecordId: bar.sourceRecordId,
                        field: 'startDate',
                        oldValue: oldStart,
                        newValue: newStartStr
                    });
                }
                if (newEndStr !== oldEnd) {
                    self.pendingChanges.push({
                        sourceTableId: bar.sourceTableId,
                        sourceRecordId: bar.sourceRecordId,
                        field: 'endDate',
                        oldValue: oldEnd,
                        newValue: newEndStr
                    });
                }

                self._updateDirtyState();
                self._render(); // Re-render with new positions
            }

            log('Interaction', 'Drag end: ' + dragMode);
        }

        barEl.addEventListener('mousedown', function (e) {
            if (e.target === handleL || e.target === handleR) return;
            onDown(e, 'move');
        });
        handleL.addEventListener('mousedown', function (e) { onDown(e, 'resize-left'); });
        handleR.addEventListener('mousedown', function (e) { onDown(e, 'resize-right'); });
    };

    // ─── View Switching (called from AL) ───
    GanttEngine.prototype.switchView = function (viewCode) {
        log('View', 'switchView called: ' + viewCode);
        // This is handled via AL callback round-trip
    };

    // ─── Filter (called from AL) ───
    GanttEngine.prototype.applyFilter = function (filterJson) {
        log('View', 'applyFilter called', filterJson);
        // Future: client-side filtering implementation
    };

    // ─── Expose globally ───
    window.GanttEngine = new GanttEngine();
    log('Init', 'GanttEngine instance created on window');

})();
