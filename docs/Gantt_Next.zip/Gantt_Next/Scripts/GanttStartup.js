/* ============================================================
   GanttStartup.js — Business Central ControlAddIn Bridge
   Connects the GanttEngine to BC's extensibility methods.
   Must be loaded AFTER GanttEngine.js and GanttInteraction.js
   ============================================================ */

(function () {
    'use strict';

    console.log('[GanttNext] [Startup] Script loaded');
    console.log('[GanttNext] [Startup] window.GanttEngine exists:', !!window.GanttEngine);

    // Wait for the Gantt container to appear
    var checkReady = setInterval(function () {
        var container = document.getElementById('gantt-next-container');
        if (container) {
            clearInterval(checkReady);
            console.log('[GanttNext] [Startup] Container found, firing OnControlReady');
            if (typeof Microsoft !== 'undefined' && Microsoft.Dynamics && Microsoft.Dynamics.NAV) {
                Microsoft.Dynamics.NAV.InvokeExtensibilityMethod('OnControlReady', []);
            }
        }
    }, 100);

    // ─── AL → JS Bridge Functions ───

    window.LoadData = function (dataJson) {
        console.log('[GanttNext] [Startup] LoadData called, length:', dataJson ? dataJson.length : 0);
        if (window.GanttEngine) {
            window.GanttEngine.load(dataJson);
        } else {
            console.log('[GanttNext] [Startup] ERROR: GanttEngine not found!');
        }
    };

    window.SwitchView = function (viewCode) {
        console.log('[GanttNext] [Startup] SwitchView called:', viewCode);
        if (window.GanttEngine) {
            window.GanttEngine.switchView(viewCode);
        }
    };

    window.ApplyFilter = function (filterJson) {
        console.log('[GanttNext] [Startup] ApplyFilter called');
        if (window.GanttEngine) {
            window.GanttEngine.applyFilter(filterJson);
        }
    };

})();
